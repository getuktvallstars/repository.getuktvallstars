import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnVrdHZkaXJlY3Q=')

name = b.b64decode('VUtUViBEaXJlY3Q=')

host = b.b64decode('aHR0cDovL3VrdHZkaXJlY3QuaW5mbw==')

port = b.b64decode('ODA=')